# Workflow Patterns

Each pattern follows the same shape:

- **The situation**: when this pattern applies
- **The pattern**: the actual steps
- **Why it works**: the underlying principle
- **A worked example**: a real-ish scenario start to finish
- **Failure modes**: when it goes wrong and how to spot it
- **Variations**: small tweaks for adjacent situations

The patterns are independent. Read whichever solves your current problem.

## The patterns

1. [Spec-First Refactor](./01-spec-first-refactor.md) - keep Claude on the rails for non-trivial rewrites
2. [Bug Bisect Loop](./02-bug-bisect-loop.md) - systematically find a bug Claude keeps guessing wrong about
3. [Codebase Tour](./03-codebase-tour.md) - get oriented in a repo you don't know
4. [Critic Pass](./04-critic-pass.md) - find the issues in Claude's first answer
5. [Plan Then Execute](./05-plan-then-execute.md) - separate planning from doing for better outcomes

## When none of these fit

If you have a recurring workflow that none of these capture, that's exactly the kind of pattern this repo wants. See [CONTRIBUTING.md](../CONTRIBUTING.md).
