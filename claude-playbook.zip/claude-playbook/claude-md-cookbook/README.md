# CLAUDE.md Cookbook

Real CLAUDE.md configurations for real project shapes. Each entry has:

- **The project shape** it's designed for
- **The actual `CLAUDE.md` content** (copy-pasteable)
- **Decisions and reasoning** for each section
- **What's deliberately not included** and why

## Why CLAUDE.md matters more than people think

Every Claude Code session loads your CLAUDE.md as context. A well-written one means:

- Claude knows your stack without you re-explaining
- Claude follows your conventions without arguing
- Claude avoids the foot-guns specific to your codebase
- Claude makes the right choices at decision points without asking

A poorly written one (or worse, a missing one) means re-explaining context every session, fighting Claude on conventions, and discovering that the reason yesterday's session worked was something you can't reproduce today.

## A few principles before you copy

1. **Short and load-bearing beats long and exhaustive.** A 200-line CLAUDE.md that nobody reads is worse than a 50-line one that's actually consulted.
2. **Document the surprising, not the obvious.** Don't tell Claude "Python uses indentation." Do tell Claude "we use 2-space indentation, not 4, because [reason]."
3. **Negative space is information.** "Do not use the `requests` library, we use `httpx` everywhere" is more useful than "we like httpx."
4. **Update when you correct Claude.** If you find yourself correcting the same thing three times in different sessions, that correction belongs in CLAUDE.md.
5. **Project-level + user-level.** Project CLAUDE.md goes in the repo. User-level config goes in `~/.claude/CLAUDE.md` for cross-project preferences.

## The cookbook

1. [Python Data Pipeline](./01-python-data-pipeline.md) - Snowflake, Airflow, batch ETL, ad-tech flavored
2. [Next.js Full-Stack](./02-nextjs-fullstack.md) - App Router, Prisma, server actions
3. [Polyglot Monorepo](./03-monorepo.md) - multiple stacks under one repo
4. [Rust CLI](./04-rust-cli.md) - single binary, clap, well-tested
5. [Research Codebase](./05-research-codebase.md) - notebooks, experiments, fast iteration

Don't copy any of these wholesale. Read the reasoning, take the parts that fit your project, write your own.
